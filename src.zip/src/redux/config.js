const config = {
  apiUrl: 'http://api.testing.justplay.tech:8000',
};

export default config;
