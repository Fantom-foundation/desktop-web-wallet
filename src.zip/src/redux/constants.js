// eslint-disable-next-line import/prefer-default-export
export const CREATE_NEW_ACCOUNT = 'CREATE_NEW_ACCOUNT';
export const CREATE_WALLET = 'CREATE_WALLET';
export const MASTER_PUBLIC_PRIVATE_KEY = 'MASTER_PUBLIC_PRIVATE_KEY';
export const MNEMONIC_CODE = 'MNEMONIC_CODE';
export const ACCOUNT_IN_PROGRESS = 'ACCOUNT_IN_PROGRESS';
export const INCREMENT_STEP_NO = 'INCREMENT_STEP_NO';
export const CONFIRMATION_PHASE = 'I have written down the phrase';
export const EMPTY_STATE = 'EMPTY_STATE';
export const SAVE_KEY_STORE = 'SAVE_KEY_STORE';
export const EMPTY_KEYS_STATE = 'EMPTY_KEYS_STATE';
